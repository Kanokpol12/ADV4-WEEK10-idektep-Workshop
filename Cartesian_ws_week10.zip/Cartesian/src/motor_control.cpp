#include <Arduino.h>
#include <AccelStepper.h>
#include <stdint.h>
#include <Servo.h>

Servo myservo1; // Gripper
Servo myservo2; // Rotator

#define MOTORX_STEP_PIN 2
#define MOTORX_DIR_PIN 5
#define MOTORY_STEP_PIN 3
#define MOTORY_DIR_PIN 6
#define MOTORZ_STEP_PIN 4
#define MOTORZ_DIR_PIN 7

//---------- Limit switch ----------//
#define LIMITSWITCHX_PIN 9
#define LIMITSWITCHY_PIN 10
#define LIMITSWITCHZ_PIN 11
#define INTERRUPT_PIN 99 
//---------------------------------//

// <<< --- CONSTANTS FOR MOVEMENT --- >>>
int MICROSTEP_RES = 16;
int STEPRATE = 50;
int TO_MILLI = 10; 

// <<< --- SOFTWARE LIMITS (สำคัญมาก) --- >>>
// (ค่าจากโค้ดเดิมของคุณ)
const float MAX_TRAVEL_X = 180.0; 
const float MAX_TRAVEL_Y = 185.0; 
const float MAX_TRAVEL_Z = 160.0; 

const float MIN_TRAVEL_X = -48.5; 
const float MIN_TRAVEL_Y = -1.0; 
const float MIN_TRAVEL_Z = -3.0; 
// <<< --- END SOFTWARE LIMITS --- >>>


volatile bool INTERRUPT_FLAG = false;

AccelStepper MOTORX(AccelStepper::DRIVER, MOTORX_STEP_PIN, MOTORX_DIR_PIN);
AccelStepper MOTORY(AccelStepper::DRIVER, MOTORY_STEP_PIN, MOTORY_DIR_PIN);
AccelStepper MOTORZ(AccelStepper::DRIVER, MOTORZ_STEP_PIN, MOTORZ_DIR_PIN);


void motorSetup(uint16_t maxSpeed, uint16_t maxAccel)
{
    pinMode(LIMITSWITCHX_PIN, INPUT_PULLUP);
    pinMode(LIMITSWITCHY_PIN, INPUT_PULLUP);
    pinMode(LIMITSWITCHZ_PIN, INPUT_PULLUP);

    MOTORX.setMaxSpeed(maxSpeed);
    MOTORY.setMaxSpeed(maxSpeed);
    MOTORZ.setMaxSpeed(maxSpeed);
    MOTORX.setAcceleration(maxAccel);
    MOTORY.setAcceleration(maxAccel);
    MOTORZ.setAcceleration(maxAccel);

    myservo1.attach(12); // Gripper Servo
    myservo2.attach(13); // Rotator Servo
}

//----------------Home position -----------------//
// (เหมือนเดิม)
void homePosition()
{
    // --- Z-Axis Homing ---
    MOTORZ.setSpeed(-3000); 
    while (digitalRead(LIMITSWITCHZ_PIN) == HIGH) { MOTORZ.runSpeed(); }
    MOTORZ.setCurrentPosition(0); 
    MOTORZ.moveTo(10); // ยกขึ้นเล็กน้อย
    MOTORZ.runToPosition();

    // --- Y-Axis Homing ---
    MOTORY.setSpeed(-3000); 
    while (digitalRead(LIMITSWITCHY_PIN) == HIGH) { MOTORY.runSpeed(); }
    MOTORY.setCurrentPosition(0); 
    MOTORY.moveTo(10); // ถอยออก
    MOTORY.runToPosition();

    // --- X-Axis Homing ---
    MOTORX.setSpeed(-3000); 
    while (digitalRead(LIMITSWITCHX_PIN) == HIGH) { MOTORX.runSpeed(); }
    MOTORX.setCurrentPosition(0); 
    MOTORX.moveTo(10); // ถอยออก
    MOTORX.runToPosition();

    // --- เคลื่อนที่ไปยัง Work Home (Work Offset) ---
    // (ค่าเหล่านี้คือระยะจาก Machine Zero (สวิตช์) ไปยัง Work Home (0,0,0) ของคุณ)
    float targetX_steps = 48.5 * MICROSTEP_RES * STEPRATE / TO_MILLI;
    float targetY_steps = 1.0 * MICROSTEP_RES * STEPRATE / TO_MILLI;
    float targetZ_steps = 3.0 * MICROSTEP_RES * STEPRATE / TO_MILLI;

    MOTORX.moveTo(targetX_steps);
    MOTORY.moveTo(targetY_steps);
    MOTORZ.moveTo(targetZ_steps);
    
    while (MOTORX.distanceToGo() != 0 || MOTORY.distanceToGo() != 0 || MOTORZ.distanceToGo() != 0)
    {
        MOTORX.run();
        MOTORY.run();
        MOTORZ.run();
    }
    
    // --- ตั้งค่า "Work Home" ใหม่ (0,0,0) ---
    MOTORX.setCurrentPosition(0); 
    MOTORY.setCurrentPosition(0);
    MOTORZ.setCurrentPosition(0);
    
    delay(1000);
}

//---------------------------------------------------------//

void moveTomm(float targetX, float targetY, float targetZ)
{
    // <<< --- MODIFIED: CONSTRAIN TARGETS (SOFTWARE LIMITS) --- >>>
    if (targetX < MIN_TRAVEL_X) { 
        targetX = MIN_TRAVEL_X; 
        Serial.print("Warning: X target < MIN");
    }
    if (targetX > MAX_TRAVEL_X) {
        targetX = MAX_TRAVEL_X;
        Serial.print("Warning: X target > MAX");
    }
    if (targetY < MIN_TRAVEL_Y) { 
        targetY = MIN_TRAVEL_Y; 
        Serial.print("Warning: Y target < MIN");
    }
    if (targetY > MAX_TRAVEL_Y) {
        targetY = MAX_TRAVEL_Y;
        Serial.print("Warning: Y target > MAX");
    }
    if (targetZ < MIN_TRAVEL_Z) { 
        targetZ = MIN_TRAVEL_Z; 
        Serial.print("Warning: Z target < MIN");
    }
    if (targetZ > MAX_TRAVEL_Z) {
        targetZ = MAX_TRAVEL_Z;
        Serial.print("Warning: Z target > MAX");
    }
    // <<< --- END MODIFIED --- >>>


    MOTORX.setSpeed(10000); 
    MOTORY.setSpeed(10000); 
    MOTORZ.setSpeed(10000); 

    float stepsX = targetX * MICROSTEP_RES * STEPRATE / TO_MILLI;
    float stepsY = targetY * MICROSTEP_RES * STEPRATE / TO_MILLI;
    float stepsZ = targetZ * MICROSTEP_RES * STEPRATE / TO_MILLI;

    MOTORX.moveTo(stepsX);
    MOTORY.moveTo(stepsY);
    MOTORZ.moveTo(stepsZ);

    while (MOTORX.distanceToGo() != 0 || MOTORY.distanceToGo() != 0 || MOTORZ.distanceToGo() != 0)
    {
        if (INTERRUPT_FLAG)
        {
            // ... (โค้ด Interrupt) ...
            break; 
        }
        else
        {
            // <<< --- HARDWARE SAFETY STOP (for 0-end) --- >>>
            if (digitalRead(LIMITSWITCHX_PIN) == LOW && MOTORX.speed() < 0) {
                MOTORX.stop(); 
                MOTORX.setCurrentPosition(MIN_TRAVEL_X * MICROSTEP_RES * STEPRATE / TO_MILLI); 
            } else { MOTORX.run(); }

            if (digitalRead(LIMITSWITCHY_PIN) == LOW && MOTORY.speed() < 0) {
                MOTORY.stop();
                MOTORY.setCurrentPosition(MIN_TRAVEL_Y * MICROSTEP_RES * STEPRATE / TO_MILLI);
            } else { MOTORY.run(); }

            if (digitalRead(LIMITSWITCHZ_PIN) == LOW && MOTORZ.speed() < 0) {
                MOTORZ.stop();
                MOTORZ.setCurrentPosition(MIN_TRAVEL_Z * MICROSTEP_RES * STEPRATE / TO_MILLI);
            } else { MOTORZ.run(); }
            // <<< --- END HARDWARE SAFETY --- >>>
        }
    }
}

//----------------------------------- Servo control ---------------//
void Gripped(float pos)
{
    myservo1.write(pos); // 25 [ grasp ] --- 160 [ release ]
}

void Rotate(float pos)
{
    myservo2.write(pos); // 9 [ 0 deg.]   --- 102 [ 90 deg.]
}

//-----------------------------------------------------------------//

void interruptLoop()
{
    INTERRUPT_FLAG = true; 
}

void resetBoard()
{
    Serial.println("Arduino reset...");
    delay(1000);
    asm volatile("  jmp 0"); 
}


//
// <<< --- MODIFIED FUNCTION (สำคัญมาก) --- >>>
//
void receiveSerialCommand()
{
    if (Serial.available())
    {
        String command = Serial.readStringUntil('\n');
        command.trim(); // ลบช่องว่างหน้า-หลัง

        if (command.length() == 0) {
            return; // ถ้าเป็นค่าว่าง (เช่น \n เปล่าๆ) ให้ออกเลย
        }

        if (command == "home")
        {
            Serial.println("Start homing...");
            homePosition();
            Serial.println("Sethome position"); // แจ้งกลับ Python
        }
        else if (command == "ready")
        {
            Serial.println("Ready to detect"); // แจ้งกลับ Python
        }
        else if (command.startsWith("G"))
        {
            int xIndex = command.indexOf('X');
            int yIndex = command.indexOf('Y');

            if (xIndex > 0 && yIndex > 0)
            {
                // --- 1. รับพิกัด "หยิบ" ---
                float x = command.substring(xIndex + 1, yIndex).toFloat();
                float y = command.substring(yIndex + 1).toFloat();
                
                // --- 2. กำหนดพิกัด "ทิ้ง" (0,0,0) ---
                float x_place = 0.0;
                float y_place = 0.0;
                float z_safe = 0.0;     // Z ด้านบน (Work Home)
                float z_pick = 112.0;   // Z ลงไปหยิบ
                float z_place = 108.0;  // Z ลงไปวาง

                Serial.print("Picking from X:"); Serial.print(x);
                Serial.print(" Y:"); Serial.println(y);
                Serial.print("Placing at X:"); Serial.print(x_place);
                Serial.print(" Y:"); Serial.println(y_place);

                //------------ Pick and Place Sequence (Drop at 0,0,0) ------------------//
                
                // 1. ไปที่ตำแหน่ง "หยิบ" (Z = 0 คือด้านบน)
                moveTomm(_____, _____, _____); 
                Rotate(9); 
                delay(1000);

                // 2. ลงไป "หยิบ"
                moveTomm(_____,_____, 112); 
                Gripped(25); // หนีบ
                delay(1000); 

                // 3. ยกวัตถุขึ้น
                moveTomm(_____, _____, _____); 
                delay(1000); 

                // 4. ไปที่ตำแหน่ง "ทิ้ง" (X, Y = 0,0)
                moveTomm(_____, _____, 0);
                delay(1000);
                
                // 5. ลงไป "วาง"
                moveTomm(_____, _____, 108);
                Gripped(160); // ปล่อย (อัปเดตค่าเป็น 160)
                delay(1000); 

                // 6. ยกขึ้น
                moveTomm(0, 0, 0); 
                delay(500);

                // 7. (สำคัญ) ไม่ต้อง Homing
                //    เราจะค้างไว้ที่ (0,0,0) เพื่อรอคำสั่งต่อไป
                
                Serial.println("Sucess to pick and place objects"); // แจ้งกลับ Python
            }
        }
        else
        {
            Serial.print("Unknown command: [");
            Serial.print(command);
            Serial.println("]");
        }
    }
}

